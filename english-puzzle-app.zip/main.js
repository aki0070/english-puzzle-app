
function playAudio() {
    let audio = new Audio('audio/example.mp3');
    audio.play();
}
